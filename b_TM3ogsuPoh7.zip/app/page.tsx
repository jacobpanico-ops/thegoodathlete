"use client"

import { useState } from "react"
import { AuthScreen } from "@/components/auth-screen"
import { Dashboard } from "@/components/dashboard"
import { DailyHuddle } from "@/components/daily-huddle"
import { Leaderboard } from "@/components/leaderboard"
import { Navigation } from "@/components/navigation"
import { Toast } from "@/components/toast"

export type View = "dashboard" | "huddle" | "leaderboard" | "profile"

export interface User {
  id: string
  email: string
  name: string
  grade: string
  sports: string[]
  xp: number
  streak: number
}

// Demo user for showcase
const DEMO_USER: User = {
  id: "demo-1",
  email: "athlete@school.edu",
  name: "Marcus Johnson",
  grade: "11",
  sports: ["Football", "Track & Field"],
  xp: 1450,
  streak: 12
}

export default function Page() {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [user, setUser] = useState<User | null>(null)
  const [view, setView] = useState<View>("dashboard")
  const [toast, setToast] = useState<{ message: string; type: "ok" | "err" } | null>(null)

  const showToast = (message: string, type: "ok" | "err" = "ok") => {
    setToast({ message, type })
    setTimeout(() => setToast(null), 3000)
  }

  const handleAuth = () => {
    setUser(DEMO_USER)
    setIsAuthenticated(true)
    showToast("Welcome back, champion!", "ok")
  }

  if (!isAuthenticated) {
    return (
      <>
        <AuthScreen onAuth={handleAuth} showToast={showToast} />
        {toast && <Toast message={toast.message} type={toast.type} />}
      </>
    )
  }

  return (
    <div className="min-h-screen bg-background bg-grid">
      {/* Ambient glow effects */}
      <div className="pointer-events-none fixed inset-0 overflow-hidden">
        <div className="absolute -left-40 -top-40 h-80 w-80 rounded-full bg-primary/5 blur-3xl" />
        <div className="absolute -bottom-40 -right-40 h-80 w-80 rounded-full bg-accent/5 blur-3xl" />
      </div>

      <main className="relative pb-24">
        {view === "dashboard" && (
          <Dashboard 
            user={user!} 
            onStartHuddle={() => setView("huddle")} 
          />
        )}
        {view === "huddle" && (
          <DailyHuddle 
            user={user!} 
            onComplete={() => {
              setView("dashboard")
              showToast("+25 XP earned!", "ok")
            }}
            onBack={() => setView("dashboard")}
          />
        )}
        {view === "leaderboard" && <Leaderboard currentUser={user!} />}
        {view === "profile" && (
          <div className="p-6">
            <ProfileView user={user!} onLogout={() => {
              setIsAuthenticated(false)
              setUser(null)
            }} />
          </div>
        )}
      </main>

      <Navigation currentView={view} onNavigate={setView} />
      {toast && <Toast message={toast.message} type={toast.type} />}
    </div>
  )
}

function ProfileView({ user, onLogout }: { user: User; onLogout: () => void }) {
  return (
    <div className="animate-slide-up space-y-6">
      <div className="text-center">
        <div className="mx-auto mb-4 flex h-24 w-24 items-center justify-center rounded-full bg-gradient-to-br from-primary/20 to-accent/20 text-4xl font-bold text-primary">
          {user.name.charAt(0)}
        </div>
        <h1 className="font-[family-name:var(--font-display)] text-3xl font-black uppercase tracking-tight text-foreground">
          {user.name}
        </h1>
        <p className="mt-1 text-sm uppercase tracking-[0.2em] text-muted-foreground">
          Grade {user.grade} · {user.sports.join(" · ")}
        </p>
      </div>

      <div className="glass-card rounded-2xl p-6">
        <h2 className="mb-4 text-xs uppercase tracking-[0.2em] text-muted-foreground">
          Statistics
        </h2>
        <div className="grid grid-cols-2 gap-4">
          <div className="rounded-xl bg-secondary/50 p-4 text-center">
            <div className="font-[family-name:var(--font-display)] text-3xl font-black text-primary">
              {user.xp}
            </div>
            <div className="text-xs uppercase tracking-wider text-muted-foreground">
              Total XP
            </div>
          </div>
          <div className="rounded-xl bg-secondary/50 p-4 text-center">
            <div className="font-[family-name:var(--font-display)] text-3xl font-black text-primary">
              {user.streak}
            </div>
            <div className="text-xs uppercase tracking-wider text-muted-foreground">
              Day Streak
            </div>
          </div>
        </div>
      </div>

      <button
        onClick={onLogout}
        className="w-full rounded-xl border border-destructive/20 bg-destructive/10 py-4 text-sm font-semibold uppercase tracking-wider text-destructive transition-colors hover:bg-destructive/20"
      >
        Sign Out
      </button>
    </div>
  )
}
