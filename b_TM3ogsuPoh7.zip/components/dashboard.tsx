"use client"

import type { User } from "@/app/page"
import { cn } from "@/lib/utils"

// Level system
const LEVELS = [
  { l: 1, x: 0, t: "Rookie", i: "◇" },
  { l: 2, x: 80, t: "Contender", i: "◈" },
  { l: 3, x: 200, t: "Competitor", i: "▲" },
  { l: 4, x: 380, t: "Grinder", i: "◆" },
  { l: 5, x: 600, t: "Threat", i: "⬡" },
  { l: 6, x: 900, t: "Dominant", i: "◆" },
  { l: 7, x: 1300, t: "Relentless", i: "▶" },
  { l: 8, x: 1800, t: "Elite", i: "◆" },
  { l: 9, x: 2400, t: "Prime", i: "◆" },
  { l: 10, x: 3200, t: "All-World", i: "◆" },
]

function getLevel(xp: number) {
  let v = LEVELS[0]
  for (const level of LEVELS) {
    if (xp >= level.x) v = level
  }
  return v
}

function getNextLevel(xp: number) {
  for (const level of LEVELS) {
    if (xp < level.x) return level
  }
  return null
}

function getProgress(xp: number) {
  const c = getLevel(xp)
  const n = getNextLevel(xp)
  return n ? Math.min(100, ((xp - c.x) / (n.x - c.x)) * 100) : 100
}

interface DashboardProps {
  user: User
  onStartHuddle: () => void
}

export function Dashboard({ user, onStartHuddle }: DashboardProps) {
  const level = getLevel(user.xp)
  const nextLevel = getNextLevel(user.xp)
  const progress = getProgress(user.xp)

  const quickStats = [
    { label: "Sleep", value: "7.5h", status: "good" as const },
    { label: "Readiness", value: "85%", status: "good" as const },
    { label: "Strain", value: "Medium", status: "ok" as const },
    { label: "Recovery", value: "92%", status: "good" as const },
  ]

  return (
    <div className="animate-slide-up space-y-6 p-6">
      {/* Header */}
      <header className="flex items-start justify-between">
        <div>
          <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">
            Welcome back
          </p>
          <h1 className="mt-1 font-[family-name:var(--font-display)] text-4xl font-black uppercase tracking-tight text-foreground">
            {user.name.split(" ")[0]}
          </h1>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 rounded-full bg-secondary/50 px-4 py-2">
            <span className="text-lg">🔥</span>
            <span className="font-bold text-primary">{user.streak}</span>
          </div>
        </div>
      </header>

      {/* Level Card */}
      <div className="glass-card glow-green overflow-hidden rounded-2xl">
        <div className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">
                Current Level
              </p>
              <div className="mt-2 flex items-baseline gap-3">
                <span className="text-3xl">{level.i}</span>
                <h2 className="font-[family-name:var(--font-display)] text-3xl font-black uppercase tracking-tight text-foreground">
                  {level.t}
                </h2>
              </div>
            </div>
            <div className="text-right">
              <span className="font-[family-name:var(--font-display)] text-5xl font-black text-primary">
                {user.xp}
              </span>
              <p className="text-xs uppercase tracking-wider text-muted-foreground">XP</p>
            </div>
          </div>

          {/* Progress bar */}
          <div className="mt-6">
            <div className="mb-2 flex justify-between text-xs uppercase tracking-wider text-muted-foreground">
              <span>Level {level.l}</span>
              {nextLevel && <span>Level {nextLevel.l} · {nextLevel.x} XP</span>}
            </div>
            <div className="h-3 overflow-hidden rounded-full bg-secondary">
              <div
                className="progress-athletic h-full rounded-full transition-all duration-1000"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Daily Huddle CTA */}
      <button
        onClick={onStartHuddle}
        className="group relative w-full overflow-hidden rounded-2xl bg-gradient-to-r from-primary via-primary to-accent p-px"
      >
        <div className="relative rounded-2xl bg-card px-6 py-8 transition-colors group-hover:bg-card/80">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs uppercase tracking-[0.2em] text-primary">
                Daily Check-In
              </p>
              <h3 className="mt-2 font-[family-name:var(--font-display)] text-2xl font-black uppercase tracking-tight text-foreground">
                Start Your Huddle
              </h3>
              <p className="mt-1 text-sm text-muted-foreground">
                60 seconds to optimize your day
              </p>
            </div>
            <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary text-3xl text-primary-foreground shadow-lg shadow-primary/30 transition-transform group-hover:scale-110">
              →
            </div>
          </div>
        </div>
      </button>

      {/* Quick Stats Grid */}
      <div className="grid grid-cols-2 gap-3">
        {quickStats.map((stat) => (
          <div
            key={stat.label}
            className="glass-card rounded-xl p-4"
          >
            <p className="text-xs uppercase tracking-[0.15em] text-muted-foreground">
              {stat.label}
            </p>
            <div className="mt-2 flex items-end justify-between">
              <span className="font-[family-name:var(--font-display)] text-2xl font-bold text-foreground">
                {stat.value}
              </span>
              <StatusDot status={stat.status} />
            </div>
          </div>
        ))}
      </div>

      {/* Recent Activity */}
      <div className="glass-card rounded-2xl p-6">
        <h3 className="mb-4 text-xs uppercase tracking-[0.2em] text-muted-foreground">
          Recent Activity
        </h3>
        <div className="space-y-4">
          {[
            { action: "Completed Team Practice", xp: "+15 XP", time: "2h ago", sport: "Football" },
            { action: "Morning Huddle", xp: "+25 XP", time: "8h ago", sport: "General" },
            { action: "Strength Training", xp: "+20 XP", time: "Yesterday", sport: "Track & Field" },
          ].map((activity, i) => (
            <div key={i} className="flex items-center justify-between border-b border-border/50 pb-4 last:border-0 last:pb-0">
              <div>
                <p className="font-medium text-foreground">{activity.action}</p>
                <p className="mt-0.5 text-xs text-muted-foreground">
                  {activity.sport} · {activity.time}
                </p>
              </div>
              <span className="font-[family-name:var(--font-display)] font-bold text-primary">
                {activity.xp}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

function StatusDot({ status }: { status: "good" | "ok" | "alert" }) {
  return (
    <div
      className={cn(
        "h-3 w-3 rounded-full",
        status === "good" && "bg-primary shadow-lg shadow-primary/50",
        status === "ok" && "bg-yellow-500 shadow-lg shadow-yellow-500/50",
        status === "alert" && "bg-destructive shadow-lg shadow-destructive/50"
      )}
    />
  )
}
