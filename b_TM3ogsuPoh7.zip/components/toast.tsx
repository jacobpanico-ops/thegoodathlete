"use client"

import { cn } from "@/lib/utils"

interface ToastProps {
  message: string
  type: "ok" | "err"
}

export function Toast({ message, type }: ToastProps) {
  return (
    <div
      className={cn(
        "fixed left-1/2 top-6 z-[100] -translate-x-1/2 animate-slide-up",
        "rounded-full px-6 py-3 shadow-xl",
        "font-semibold tracking-wide",
        type === "ok"
          ? "bg-gradient-to-r from-primary to-primary/80 text-primary-foreground shadow-primary/30"
          : "bg-gradient-to-r from-destructive to-destructive/80 text-destructive-foreground shadow-destructive/30"
      )}
    >
      <div className="flex items-center gap-2">
        {type === "ok" ? (
          <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
          </svg>
        ) : (
          <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
          </svg>
        )}
        {message}
      </div>
    </div>
  )
}
