"use client"

import { useState } from "react"
import { cn } from "@/lib/utils"

interface AuthScreenProps {
  onAuth: () => void
  showToast: (message: string, type: "ok" | "err") => void
}

export function AuthScreen({ onAuth, showToast }: AuthScreenProps) {
  const [mode, setMode] = useState<"signin" | "signup">("signin")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!email.trim() || !password.trim()) {
      showToast("Fill in all fields", "err")
      return
    }
    if (password.length < 6) {
      showToast("Password must be 6+ characters", "err")
      return
    }

    setLoading(true)
    // Simulate auth delay
    await new Promise(resolve => setTimeout(resolve, 800))
    setLoading(false)
    onAuth()
  }

  return (
    <div className="relative flex min-h-screen flex-col justify-center px-6 py-12">
      {/* Background effects */}
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="absolute left-1/2 top-[10%] h-[600px] w-[600px] -translate-x-1/2 rounded-full bg-primary/5 blur-3xl" />
        <div className="absolute bottom-0 left-0 h-[400px] w-[400px] rounded-full bg-accent/5 blur-3xl" />
      </div>

      {/* Logo & Brand */}
      <div className="relative z-10 mb-12 text-center">
        <div className="animate-float mb-6 inline-block">
          <div className="flex h-20 w-20 items-center justify-center rounded-2xl bg-gradient-to-br from-primary to-primary/50 text-4xl font-black text-primary-foreground shadow-lg shadow-primary/25">
            ◆
          </div>
        </div>
        
        <h1 className="animate-shimmer font-[family-name:var(--font-display)] text-5xl font-black uppercase tracking-tight sm:text-6xl md:text-7xl">
          The Good<br />Athlete
        </h1>
        
        <p className="mt-4 text-sm uppercase tracking-[0.3em] text-primary/80">
          Train · Track · Dominate
        </p>
      </div>

      {/* Auth Form */}
      <div className="relative z-10 mx-auto w-full max-w-sm">
        {/* Mode Tabs */}
        <div className="mb-6 flex gap-2 rounded-xl bg-secondary/50 p-1">
          {(["signin", "signup"] as const).map((m) => (
            <button
              key={m}
              onClick={() => setMode(m)}
              className={cn(
                "flex-1 rounded-lg py-3 text-sm font-semibold uppercase tracking-wider transition-all",
                mode === m
                  ? "bg-primary text-primary-foreground shadow-lg shadow-primary/25"
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              {m === "signin" ? "Sign In" : "Sign Up"}
            </button>
          ))}
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="mb-2 block text-xs uppercase tracking-[0.2em] text-muted-foreground">
              Email
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@school.edu"
              className="w-full rounded-xl border-2 border-border bg-input px-4 py-4 text-base font-medium text-foreground placeholder:text-muted-foreground/50 focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20"
            />
          </div>

          <div>
            <label className="mb-2 block text-xs uppercase tracking-[0.2em] text-muted-foreground">
              Password
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder={mode === "signup" ? "Create password (6+ chars)" : "Your password"}
              className="w-full rounded-xl border-2 border-border bg-input px-4 py-4 text-base font-medium text-foreground placeholder:text-muted-foreground/50 focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20"
            />
          </div>

          <button
            type="submit"
            disabled={loading || !email.trim() || !password.trim()}
            className={cn(
              "group relative w-full overflow-hidden rounded-xl py-5 text-lg font-bold uppercase tracking-wider transition-all",
              "bg-gradient-to-r from-primary via-primary to-primary/80",
              "text-primary-foreground shadow-xl shadow-primary/30",
              "hover:shadow-2xl hover:shadow-primary/40",
              "disabled:cursor-not-allowed disabled:opacity-50 disabled:shadow-none",
              "active:scale-[0.98]"
            )}
          >
            <span className="relative z-10 flex items-center justify-center gap-2">
              {loading ? (
                <span className="inline-block h-5 w-5 animate-spin rounded-full border-2 border-primary-foreground/30 border-t-primary-foreground" />
              ) : (
                <>
                  {mode === "signin" ? "Let's Go" : "Create Account"}
                  <svg 
                    className="h-5 w-5 transition-transform group-hover:translate-x-1" 
                    fill="none" 
                    viewBox="0 0 24 24" 
                    stroke="currentColor"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                  </svg>
                </>
              )}
            </span>
          </button>
        </form>

        {mode === "signup" && (
          <p className="mt-6 text-center text-sm text-muted-foreground">
            Already have an account?{" "}
            <button
              onClick={() => setMode("signin")}
              className="font-semibold text-primary hover:underline"
            >
              Sign In
            </button>
          </p>
        )}
      </div>

      {/* Bottom decoration */}
      <div className="relative z-10 mt-12 text-center">
        <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground/50">
          Built for Elite Athletes
        </p>
      </div>
    </div>
  )
}
