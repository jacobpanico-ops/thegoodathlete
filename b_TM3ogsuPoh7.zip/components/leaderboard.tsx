"use client"

import type { User } from "@/app/page"
import { cn } from "@/lib/utils"

// Mock leaderboard data
const LEADERBOARD_DATA = [
  { rank: 1, name: "Sarah Chen", xp: 2840, streak: 28, sports: ["Basketball", "Track"], avatar: "S" },
  { rank: 2, name: "Marcus Johnson", xp: 1450, streak: 12, sports: ["Football", "Track"], avatar: "M" },
  { rank: 3, name: "Jaylen Williams", xp: 1380, streak: 15, sports: ["Basketball"], avatar: "J" },
  { rank: 4, name: "Emma Rodriguez", xp: 1250, streak: 21, sports: ["Soccer", "Swimming"], avatar: "E" },
  { rank: 5, name: "Tyler Brooks", xp: 1180, streak: 8, sports: ["Football"], avatar: "T" },
  { rank: 6, name: "Mia Thompson", xp: 1050, streak: 14, sports: ["Volleyball"], avatar: "M" },
  { rank: 7, name: "Darius Jackson", xp: 980, streak: 6, sports: ["Basketball", "Football"], avatar: "D" },
  { rank: 8, name: "Olivia Davis", xp: 920, streak: 19, sports: ["Tennis"], avatar: "O" },
  { rank: 9, name: "Ethan Martinez", xp: 850, streak: 10, sports: ["Soccer"], avatar: "E" },
  { rank: 10, name: "Ava Wilson", xp: 780, streak: 7, sports: ["Softball"], avatar: "A" },
]

interface LeaderboardProps {
  currentUser: User
}

export function Leaderboard({ currentUser }: LeaderboardProps) {
  // Find current user's rank
  const userEntry = LEADERBOARD_DATA.find(e => e.name === currentUser.name)
  const userRank = userEntry?.rank || 2

  return (
    <div className="animate-slide-up space-y-6 p-6">
      {/* Header */}
      <header>
        <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">
          Rankings
        </p>
        <h1 className="mt-1 font-[family-name:var(--font-display)] text-4xl font-black uppercase tracking-tight text-foreground">
          Leaderboard
        </h1>
      </header>

      {/* Top 3 Podium */}
      <div className="flex items-end justify-center gap-4">
        {/* 2nd Place */}
        <PodiumCard
          rank={2}
          name={LEADERBOARD_DATA[1].name}
          xp={LEADERBOARD_DATA[1].xp}
          avatar={LEADERBOARD_DATA[1].avatar}
          isCurrentUser={LEADERBOARD_DATA[1].name === currentUser.name}
          className="h-28"
        />
        {/* 1st Place */}
        <PodiumCard
          rank={1}
          name={LEADERBOARD_DATA[0].name}
          xp={LEADERBOARD_DATA[0].xp}
          avatar={LEADERBOARD_DATA[0].avatar}
          isCurrentUser={LEADERBOARD_DATA[0].name === currentUser.name}
          className="h-36"
        />
        {/* 3rd Place */}
        <PodiumCard
          rank={3}
          name={LEADERBOARD_DATA[2].name}
          xp={LEADERBOARD_DATA[2].xp}
          avatar={LEADERBOARD_DATA[2].avatar}
          isCurrentUser={LEADERBOARD_DATA[2].name === currentUser.name}
          className="h-24"
        />
      </div>

      {/* Current User Card */}
      <div className="glass-card glow-green rounded-2xl p-4">
        <div className="flex items-center gap-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-br from-primary to-primary/50 text-xl font-bold text-primary-foreground">
            #{userRank}
          </div>
          <div className="flex-1">
            <p className="font-semibold text-foreground">{currentUser.name}</p>
            <p className="text-sm text-muted-foreground">Your current rank</p>
          </div>
          <div className="text-right">
            <span className="font-[family-name:var(--font-display)] text-2xl font-black text-primary">
              {currentUser.xp}
            </span>
            <p className="text-xs text-muted-foreground">XP</p>
          </div>
        </div>
      </div>

      {/* Full Rankings List */}
      <div className="glass-card rounded-2xl">
        <div className="border-b border-border/50 p-4">
          <h3 className="text-xs uppercase tracking-[0.2em] text-muted-foreground">
            All Athletes
          </h3>
        </div>
        <div className="divide-y divide-border/30">
          {LEADERBOARD_DATA.map((entry, i) => (
            <LeaderboardRow
              key={entry.rank}
              entry={entry}
              isCurrentUser={entry.name === currentUser.name}
              animationDelay={i * 50}
            />
          ))}
        </div>
      </div>
    </div>
  )
}

function PodiumCard({
  rank,
  name,
  xp,
  avatar,
  isCurrentUser,
  className,
}: {
  rank: number
  name: string
  xp: number
  avatar: string
  isCurrentUser: boolean
  className?: string
}) {
  const colors = {
    1: "from-yellow-400 to-yellow-600",
    2: "from-gray-300 to-gray-400",
    3: "from-amber-600 to-amber-700",
  }

  const bgColors = {
    1: "bg-yellow-500/10",
    2: "bg-gray-400/10",
    3: "bg-amber-600/10",
  }

  return (
    <div
      className={cn(
        "flex w-28 flex-col items-center justify-end rounded-t-2xl transition-all",
        bgColors[rank as keyof typeof bgColors],
        isCurrentUser && "ring-2 ring-primary",
        className
      )}
    >
      {/* Avatar */}
      <div
        className={cn(
          "mb-2 flex h-14 w-14 items-center justify-center rounded-full bg-gradient-to-br text-xl font-bold text-white shadow-lg",
          colors[rank as keyof typeof colors]
        )}
      >
        {avatar}
      </div>
      
      {/* Name */}
      <p className="mb-1 w-full truncate px-2 text-center text-xs font-medium text-foreground">
        {name.split(" ")[0]}
      </p>
      
      {/* XP */}
      <p className="mb-3 font-[family-name:var(--font-display)] text-sm font-bold text-muted-foreground">
        {xp} XP
      </p>
      
      {/* Rank Badge */}
      <div
        className={cn(
          "flex h-8 w-full items-center justify-center rounded-t-lg bg-gradient-to-b text-lg font-black text-white",
          colors[rank as keyof typeof colors]
        )}
      >
        {rank}
      </div>
    </div>
  )
}

function LeaderboardRow({
  entry,
  isCurrentUser,
  animationDelay,
}: {
  entry: typeof LEADERBOARD_DATA[0]
  isCurrentUser: boolean
  animationDelay: number
}) {
  return (
    <div
      className={cn(
        "flex items-center gap-4 p-4 transition-colors",
        isCurrentUser && "bg-primary/5"
      )}
      style={{ animationDelay: `${animationDelay}ms` }}
    >
      {/* Rank */}
      <div
        className={cn(
          "flex h-8 w-8 items-center justify-center rounded-full text-sm font-bold",
          entry.rank <= 3
            ? "bg-gradient-to-br from-primary to-accent text-primary-foreground"
            : "bg-secondary text-muted-foreground"
        )}
      >
        {entry.rank}
      </div>

      {/* Avatar */}
      <div className="flex h-10 w-10 items-center justify-center rounded-full bg-secondary text-lg font-bold text-foreground">
        {entry.avatar}
      </div>

      {/* Info */}
      <div className="flex-1">
        <p className={cn("font-semibold", isCurrentUser ? "text-primary" : "text-foreground")}>
          {entry.name}
          {isCurrentUser && <span className="ml-2 text-xs text-muted-foreground">(You)</span>}
        </p>
        <div className="flex items-center gap-2">
          <span className="text-xs text-muted-foreground">
            {entry.sports[0]}
          </span>
          <span className="flex items-center gap-1 text-xs text-primary">
            🔥 {entry.streak}
          </span>
        </div>
      </div>

      {/* XP */}
      <div className="text-right">
        <span className="font-[family-name:var(--font-display)] text-xl font-bold text-foreground">
          {entry.xp.toLocaleString()}
        </span>
        <p className="text-xs text-muted-foreground">XP</p>
      </div>
    </div>
  )
}
