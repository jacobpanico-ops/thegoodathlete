"use client"

import { useState } from "react"
import type { User } from "@/app/page"
import { cn } from "@/lib/utils"

interface DailyHuddleProps {
  user: User
  onComplete: () => void
  onBack: () => void
}

const READINESS_OPTIONS = [
  { emoji: "🔥", label: "Fired Up", value: 5 },
  { emoji: "💪", label: "Strong", value: 4 },
  { emoji: "👍", label: "Good", value: 3 },
  { emoji: "😐", label: "Okay", value: 2 },
  { emoji: "😴", label: "Tired", value: 1 },
]

const SLEEP_QUALITY = [
  { label: "Elite", value: 5, color: "from-primary to-primary/80" },
  { label: "Good", value: 4, color: "from-primary/80 to-primary/60" },
  { label: "Fair", value: 3, color: "from-yellow-500 to-yellow-600" },
  { label: "Poor", value: 2, color: "from-orange-500 to-orange-600" },
  { label: "Bad", value: 1, color: "from-destructive to-destructive/80" },
]

const HYDRATION_OPTIONS = [
  { label: "Optimal", value: 4, emoji: "💧💧💧" },
  { label: "Good", value: 3, emoji: "💧💧" },
  { label: "Fair", value: 2, emoji: "💧" },
  { label: "Low", value: 1, emoji: "🏜️" },
]

export function DailyHuddle({ user, onComplete, onBack }: DailyHuddleProps) {
  const [step, setStep] = useState(0)
  const [data, setData] = useState({
    sleepHours: 7,
    sleepQuality: 0,
    readiness: 0,
    soreness: [] as string[],
    mentalLoad: 3,
    hydration: 0,
    meals: 3,
  })

  const totalSteps = 5
  const progress = ((step + 1) / totalSteps) * 100

  const handleNext = () => {
    if (step < totalSteps - 1) {
      setStep(step + 1)
    } else {
      onComplete()
    }
  }

  const canProceed = () => {
    switch (step) {
      case 0: return data.sleepQuality > 0
      case 1: return data.readiness > 0
      case 2: return true // Body scan is optional
      case 3: return data.hydration > 0
      case 4: return true // Summary always can proceed
      default: return false
    }
  }

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-background/80 backdrop-blur-xl">
        <div className="flex items-center justify-between p-4">
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-foreground"
          >
            <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            Back
          </button>
          <span className="text-xs uppercase tracking-[0.2em] text-muted-foreground">
            Step {step + 1} of {totalSteps}
          </span>
        </div>
        
        {/* Progress bar */}
        <div className="h-1 bg-secondary">
          <div
            className="progress-athletic h-full transition-all duration-500"
            style={{ width: `${progress}%` }}
          />
        </div>
      </header>

      {/* Content */}
      <div className="p-6">
        {step === 0 && (
          <SleepCard
            hours={data.sleepHours}
            quality={data.sleepQuality}
            onHoursChange={(h) => setData({ ...data, sleepHours: h })}
            onQualityChange={(q) => setData({ ...data, sleepQuality: q })}
          />
        )}

        {step === 1 && (
          <ReadinessCard
            selected={data.readiness}
            onSelect={(v) => setData({ ...data, readiness: v })}
          />
        )}

        {step === 2 && (
          <BodyScanCard
            mentalLoad={data.mentalLoad}
            soreness={data.soreness}
            onMentalChange={(v) => setData({ ...data, mentalLoad: v })}
            onSorenessToggle={(area) => {
              const current = data.soreness
              if (current.includes(area)) {
                setData({ ...data, soreness: current.filter((a) => a !== area) })
              } else {
                setData({ ...data, soreness: [...current, area] })
              }
            }}
          />
        )}

        {step === 3 && (
          <FuelCard
            hydration={data.hydration}
            meals={data.meals}
            onHydrationChange={(v) => setData({ ...data, hydration: v })}
            onMealsChange={(v) => setData({ ...data, meals: v })}
          />
        )}

        {step === 4 && (
          <SummaryCard data={data} user={user} />
        )}

        {/* CTA Button */}
        <button
          onClick={handleNext}
          disabled={!canProceed()}
          className={cn(
            "mt-8 w-full rounded-xl py-5 text-lg font-bold uppercase tracking-wider transition-all",
            "bg-gradient-to-r from-primary via-primary to-primary/80",
            "text-primary-foreground shadow-xl shadow-primary/30",
            "hover:shadow-2xl hover:shadow-primary/40",
            "disabled:cursor-not-allowed disabled:opacity-50 disabled:shadow-none",
            "active:scale-[0.98]"
          )}
        >
          {step === totalSteps - 1 ? "Complete Huddle" : "Continue"}
        </button>
      </div>
    </div>
  )
}

function SleepCard({
  hours,
  quality,
  onHoursChange,
  onQualityChange,
}: {
  hours: number
  quality: number
  onHoursChange: (h: number) => void
  onQualityChange: (q: number) => void
}) {
  return (
    <div className="animate-scale-in space-y-8">
      <div className="text-center">
        <span className="text-5xl">😴</span>
        <h2 className="mt-4 font-[family-name:var(--font-display)] text-3xl font-black uppercase tracking-tight text-foreground">
          Sleep Check
        </h2>
        <p className="mt-2 text-muted-foreground">How did you rest last night?</p>
      </div>

      {/* Hours Slider */}
      <div className="glass-card rounded-2xl p-6">
        <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">
          Hours of Sleep
        </p>
        <div className="mt-4 text-center">
          <span className="font-[family-name:var(--font-display)] text-6xl font-black text-primary">
            {hours}
          </span>
          <span className="ml-2 text-2xl text-muted-foreground">hrs</span>
        </div>
        <input
          type="range"
          min={4}
          max={12}
          step={0.5}
          value={hours}
          onChange={(e) => onHoursChange(parseFloat(e.target.value))}
          className="mt-4 w-full accent-primary"
        />
        <div className="mt-2 flex justify-between text-xs text-muted-foreground">
          <span>4h</span>
          <span>8h</span>
          <span>12h</span>
        </div>
      </div>

      {/* Quality Selection */}
      <div>
        <p className="mb-4 text-center text-xs uppercase tracking-[0.2em] text-muted-foreground">
          Sleep Quality
        </p>
        <div className="grid grid-cols-5 gap-2">
          {SLEEP_QUALITY.map((opt) => (
            <button
              key={opt.value}
              onClick={() => onQualityChange(opt.value)}
              className={cn(
                "rounded-xl py-4 text-center transition-all",
                quality === opt.value
                  ? `bg-gradient-to-b ${opt.color} text-primary-foreground shadow-lg`
                  : "bg-secondary text-muted-foreground hover:bg-secondary/80"
              )}
            >
              <span className="text-xs font-semibold uppercase">{opt.label}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}

function ReadinessCard({
  selected,
  onSelect,
}: {
  selected: number
  onSelect: (v: number) => void
}) {
  return (
    <div className="animate-scale-in space-y-8">
      <div className="text-center">
        <span className="text-5xl">⚡</span>
        <h2 className="mt-4 font-[family-name:var(--font-display)] text-3xl font-black uppercase tracking-tight text-foreground">
          Readiness Check
        </h2>
        <p className="mt-2 text-muted-foreground">How are you feeling right now?</p>
      </div>

      <div className="grid gap-3">
        {READINESS_OPTIONS.map((opt) => (
          <button
            key={opt.value}
            onClick={() => onSelect(opt.value)}
            className={cn(
              "flex items-center gap-4 rounded-2xl p-5 transition-all",
              selected === opt.value
                ? "bg-gradient-to-r from-primary/20 to-accent/20 ring-2 ring-primary"
                : "bg-secondary hover:bg-secondary/80"
            )}
          >
            <span className="text-4xl">{opt.emoji}</span>
            <span className="font-[family-name:var(--font-display)] text-xl font-bold uppercase tracking-tight">
              {opt.label}
            </span>
            {selected === opt.value && (
              <div className="ml-auto h-6 w-6 rounded-full bg-primary text-center text-sm font-bold text-primary-foreground">
                ✓
              </div>
            )}
          </button>
        ))}
      </div>
    </div>
  )
}

function BodyScanCard({
  mentalLoad,
  soreness,
  onMentalChange,
  onSorenessToggle,
}: {
  mentalLoad: number
  soreness: string[]
  onMentalChange: (v: number) => void
  onSorenessToggle: (area: string) => void
}) {
  const bodyAreas = [
    "Head", "Neck", "Shoulders", "Upper Back", "Lower Back",
    "Chest", "Arms", "Hips", "Quads", "Hamstrings", "Knees", "Calves"
  ]

  return (
    <div className="animate-scale-in space-y-8">
      <div className="text-center">
        <span className="text-5xl">🧠</span>
        <h2 className="mt-4 font-[family-name:var(--font-display)] text-3xl font-black uppercase tracking-tight text-foreground">
          Body Scan
        </h2>
        <p className="mt-2 text-muted-foreground">Mental state & physical check</p>
      </div>

      {/* Mental Load */}
      <div className="glass-card rounded-2xl p-6">
        <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">
          Mental Load (Stress Level)
        </p>
        <div className="mt-4 flex items-center gap-4">
          <span className="text-2xl">😌</span>
          <input
            type="range"
            min={1}
            max={5}
            value={mentalLoad}
            onChange={(e) => onMentalChange(parseInt(e.target.value))}
            className="flex-1 accent-primary"
          />
          <span className="text-2xl">😰</span>
        </div>
        <p className="mt-2 text-center text-sm text-muted-foreground">
          {mentalLoad <= 2 ? "Low stress" : mentalLoad === 3 ? "Moderate" : "High stress"}
        </p>
      </div>

      {/* Soreness Areas */}
      <div>
        <p className="mb-4 text-center text-xs uppercase tracking-[0.2em] text-muted-foreground">
          Tap any sore areas (optional)
        </p>
        <div className="flex flex-wrap justify-center gap-2">
          {bodyAreas.map((area) => (
            <button
              key={area}
              onClick={() => onSorenessToggle(area)}
              className={cn(
                "rounded-full px-4 py-2 text-sm font-medium transition-all",
                soreness.includes(area)
                  ? "bg-destructive/20 text-destructive ring-1 ring-destructive"
                  : "bg-secondary text-muted-foreground hover:bg-secondary/80"
              )}
            >
              {area}
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}

function FuelCard({
  hydration,
  meals,
  onHydrationChange,
  onMealsChange,
}: {
  hydration: number
  meals: number
  onHydrationChange: (v: number) => void
  onMealsChange: (v: number) => void
}) {
  return (
    <div className="animate-scale-in space-y-8">
      <div className="text-center">
        <span className="text-5xl">⛽</span>
        <h2 className="mt-4 font-[family-name:var(--font-display)] text-3xl font-black uppercase tracking-tight text-foreground">
          Fuel Check
        </h2>
        <p className="mt-2 text-muted-foreground">Hydration & nutrition status</p>
      </div>

      {/* Hydration */}
      <div>
        <p className="mb-4 text-center text-xs uppercase tracking-[0.2em] text-muted-foreground">
          Hydration Level
        </p>
        <div className="grid grid-cols-2 gap-3">
          {HYDRATION_OPTIONS.map((opt) => (
            <button
              key={opt.value}
              onClick={() => onHydrationChange(opt.value)}
              className={cn(
                "rounded-2xl p-5 text-center transition-all",
                hydration === opt.value
                  ? "bg-gradient-to-b from-blue-500 to-blue-600 text-white shadow-lg"
                  : "bg-secondary text-muted-foreground hover:bg-secondary/80"
              )}
            >
              <span className="text-2xl">{opt.emoji}</span>
              <p className="mt-2 text-sm font-semibold uppercase">{opt.label}</p>
            </button>
          ))}
        </div>
      </div>

      {/* Meals */}
      <div className="glass-card rounded-2xl p-6">
        <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">
          Quality meals today
        </p>
        <div className="mt-4 flex items-center justify-center gap-4">
          <button
            onClick={() => onMealsChange(Math.max(0, meals - 1))}
            className="flex h-12 w-12 items-center justify-center rounded-full bg-secondary text-2xl font-bold transition-colors hover:bg-secondary/80"
          >
            −
          </button>
          <span className="font-[family-name:var(--font-display)] text-5xl font-black text-primary">
            {meals}
          </span>
          <button
            onClick={() => onMealsChange(Math.min(6, meals + 1))}
            className="flex h-12 w-12 items-center justify-center rounded-full bg-secondary text-2xl font-bold transition-colors hover:bg-secondary/80"
          >
            +
          </button>
        </div>
      </div>
    </div>
  )
}

function SummaryCard({ data, user }: { data: typeof INITIAL_DATA; user: User }) {
  const readinessLabel = READINESS_OPTIONS.find(o => o.value === data.readiness)?.label || "—"
  const hydrationLabel = HYDRATION_OPTIONS.find(o => o.value === data.hydration)?.label || "—"
  const sleepLabel = SLEEP_QUALITY.find(o => o.value === data.sleepQuality)?.label || "—"

  // Calculate overall readiness score
  const score = Math.round(
    ((data.sleepQuality / 5) * 25) +
    ((data.readiness / 5) * 25) +
    ((5 - data.mentalLoad) / 4 * 25) +
    ((data.hydration / 4) * 25)
  )

  return (
    <div className="animate-scale-in space-y-6">
      <div className="text-center">
        <span className="text-5xl">✅</span>
        <h2 className="mt-4 font-[family-name:var(--font-display)] text-3xl font-black uppercase tracking-tight text-foreground">
          Huddle Complete
        </h2>
        <p className="mt-2 text-muted-foreground">Here&apos;s your readiness summary</p>
      </div>

      {/* Score Circle */}
      <div className="flex justify-center">
        <div className="relative flex h-40 w-40 items-center justify-center rounded-full bg-gradient-to-br from-primary/20 to-accent/20">
          <div className="absolute inset-2 rounded-full bg-background" />
          <div className="relative text-center">
            <span className="font-[family-name:var(--font-display)] text-5xl font-black text-primary">
              {score}
            </span>
            <p className="text-xs uppercase tracking-wider text-muted-foreground">Readiness</p>
          </div>
        </div>
      </div>

      {/* Summary Grid */}
      <div className="grid grid-cols-2 gap-3">
        <SummaryItem icon="😴" label="Sleep" value={`${data.sleepHours}h · ${sleepLabel}`} />
        <SummaryItem icon="⚡" label="Energy" value={readinessLabel} />
        <SummaryItem icon="💧" label="Hydration" value={hydrationLabel} />
        <SummaryItem icon="🍽️" label="Meals" value={`${data.meals} quality`} />
      </div>

      {data.soreness.length > 0 && (
        <div className="glass-card rounded-xl p-4">
          <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">
            Areas to monitor
          </p>
          <p className="mt-2 text-sm text-foreground">{data.soreness.join(", ")}</p>
        </div>
      )}

      {/* XP Earned */}
      <div className="rounded-2xl bg-gradient-to-r from-primary/20 to-accent/20 p-6 text-center">
        <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">
          XP Earned
        </p>
        <p className="mt-2 font-[family-name:var(--font-display)] text-4xl font-black text-primary">
          +25 XP
        </p>
      </div>
    </div>
  )
}

const INITIAL_DATA = {
  sleepHours: 7,
  sleepQuality: 0,
  readiness: 0,
  soreness: [] as string[],
  mentalLoad: 3,
  hydration: 0,
  meals: 3,
}

function SummaryItem({ icon, label, value }: { icon: string; label: string; value: string }) {
  return (
    <div className="glass-card rounded-xl p-4">
      <div className="flex items-center gap-2">
        <span className="text-xl">{icon}</span>
        <span className="text-xs uppercase tracking-wider text-muted-foreground">{label}</span>
      </div>
      <p className="mt-2 font-semibold text-foreground">{value}</p>
    </div>
  )
}
